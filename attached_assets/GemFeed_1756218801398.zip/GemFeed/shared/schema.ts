import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const rssFeeds = pgTable("rss_feeds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  url: text("url").notNull(),
  category: text("category").notNull(), // 'cybersecurity', 'financial', 'real_estate', 'general'
  enabled: boolean("enabled").default(true),
  updateFrequency: integer("update_frequency").default(3600), // seconds
  lastUpdated: timestamp("last_updated"),
  status: text("status").default("active"), // 'active', 'inactive', 'error'
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const contentItems = pgTable("content_items", {
  id: varchar("id").primaryKey(),
  source: text("source").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  content: text("content"),
  url: text("url").notNull(),
  published: timestamp("published").notNull(),
  category: text("category").notNull(),
  tags: jsonb("tags").$type<string[]>().default([]),
  status: text("status").default("pending"), // 'pending', 'approved', 'rejected', 'posted'
  telegramChannels: jsonb("telegram_channels").$type<string[]>().default([]),
  customizedContent: text("customized_content"),
  aiSummary: text("ai_summary"),
  scheduledTime: timestamp("scheduled_time"),
  reviewedBy: text("reviewed_by"),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const workflowLogs = pgTable("workflow_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // 'fetch', 'customize', 'approve', 'post'
  status: text("status").notNull(), // 'success', 'error'
  message: text("message"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

// Insert schemas
export const insertRssFeedSchema = createInsertSchema(rssFeeds).omit({
  id: true,
  createdAt: true,
  lastUpdated: true,
  status: true,
  errorMessage: true,
});

export const insertContentItemSchema = createInsertSchema(contentItems).omit({
  createdAt: true,
  reviewedAt: true,
});

export const insertWorkflowLogSchema = createInsertSchema(workflowLogs).omit({
  id: true,
  createdAt: true,
});

// Types
export type RssFeed = typeof rssFeeds.$inferSelect;
export type InsertRssFeed = z.infer<typeof insertRssFeedSchema>;
export type ContentItem = typeof contentItems.$inferSelect;
export type InsertContentItem = z.infer<typeof insertContentItemSchema>;
export type WorkflowLog = typeof workflowLogs.$inferSelect;
export type InsertWorkflowLog = z.infer<typeof insertWorkflowLogSchema>;

// API Response types
export type DashboardStats = {
  totalFeeds: number;
  activeFeeds: number;
  pendingContent: number;
  approvedToday: number;
  postedWeek: number;
  feedsByCategory: Record<string, number>;
  lastUpdate: string | null;
};

export type FeedStatus = {
  id: string;
  name: string;
  category: string;
  status: string;
  lastUpdate: string | null;
  newItems: number;
  errorMessage?: string;
};

export type ContentPreview = {
  id: string;
  title: string;
  description: string;
  content: string;
  url: string;
  source: string;
  category: string;
  published: string;
  aiSummary: string | null;
  customizedContent: string | null;
  telegramFormat: string;
};
