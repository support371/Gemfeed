import { apiRequest } from "./queryClient";

export const api = {
  // Dashboard
  getDashboardStats: () => fetch("/api/dashboard/stats").then(res => res.json()),
  getFeedStatus: () => fetch("/api/dashboard/feed-status").then(res => res.json()),
  
  // RSS Feeds
  getFeeds: () => fetch("/api/feeds").then(res => res.json()),
  getFeed: (id: string) => fetch(`/api/feeds/${id}`).then(res => res.json()),
  createFeed: (data: any) => apiRequest("POST", "/api/feeds", data),
  updateFeed: (id: string, data: any) => apiRequest("PUT", `/api/feeds/${id}`, data),
  deleteFeed: (id: string) => apiRequest("DELETE", `/api/feeds/${id}`),
  
  // Content
  getContent: (params?: { status?: string; category?: string; limit?: number }) => {
    const searchParams = new URLSearchParams();
    if (params?.status) searchParams.set("status", params.status);
    if (params?.category) searchParams.set("category", params.category);
    if (params?.limit) searchParams.set("limit", params.limit.toString());
    
    const query = searchParams.toString();
    return fetch(`/api/content${query ? `?${query}` : ""}`).then(res => res.json());
  },
  getContentPreview: (id: string) => fetch(`/api/content/${id}/preview`).then(res => res.json()),
  updateContent: (id: string, data: any) => apiRequest("PUT", `/api/content/${id}`, data),
  approveContent: (id: string) => apiRequest("POST", `/api/content/${id}/approve`),
  rejectContent: (id: string) => apiRequest("POST", `/api/content/${id}/reject`),
  bulkApproveContent: (ids: string[]) => apiRequest("POST", "/api/content/bulk-approve", { ids }),
  
  // Workflow
  refreshFeeds: () => apiRequest("POST", "/api/workflow/refresh-feeds"),
  exportContent: (status = "approved") => apiRequest("POST", "/api/workflow/export-content", { status }),
};
