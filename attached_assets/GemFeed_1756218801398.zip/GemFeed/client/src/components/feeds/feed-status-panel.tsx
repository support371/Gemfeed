import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import { FeedStatus } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";

interface FeedStatusPanelProps {
  feedStatus: FeedStatus[] | undefined;
  isLoading: boolean;
  onManageFeeds: () => void;
}

export function FeedStatusPanel({ feedStatus, isLoading, onManageFeeds }: FeedStatusPanelProps) {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Feed Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center justify-between py-3">
                <div className="flex items-center space-x-3">
                  <Skeleton className="w-2 h-2 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <div className="text-right">
                  <Skeleton className="h-3 w-12 mb-1" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white dark:bg-gray-900 shadow-sm border border-gray-200 dark:border-gray-700">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
          Feed Status
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-3">
          {feedStatus?.map((feed) => (
            <div
              key={feed.id}
              className="flex items-center justify-between py-3 border-b border-gray-100 dark:border-gray-700 last:border-b-0"
              data-testid={`feed-status-${feed.id}`}
            >
              <div className="flex items-center space-x-3">
                <span
                  className={`status-dot ${
                    feed.status === "active" ? "status-active" :
                    feed.status === "error" ? "status-error" :
                    "status-inactive"
                  }`}
                />
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white" data-testid={`feed-name-${feed.id}`}>
                    {feed.name}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 capitalize" data-testid={`feed-category-${feed.id}`}>
                    {feed.category.replace('_', ' ')}
                  </p>
                </div>
              </div>
              <div className="text-right">
                {feed.status === "error" ? (
                  <p className="text-xs text-destructive" data-testid={`feed-error-${feed.id}`}>Failed</p>
                ) : (
                  <p className="text-xs text-gray-500 dark:text-gray-400" data-testid={`feed-last-update-${feed.id}`}>
                    {feed.lastUpdate ? formatDistanceToNow(new Date(feed.lastUpdate), { addSuffix: true }) : "Never"}
                  </p>
                )}
                {feed.newItems > 0 && (
                  <p className="text-xs text-success" data-testid={`feed-new-items-${feed.id}`}>
                    +{feed.newItems} new
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 bg-gray-50 dark:bg-gray-800 rounded-b-xl -m-6 p-4">
          <Button
            variant="ghost"
            onClick={onManageFeeds}
            className="w-full text-primary hover:text-indigo-600 text-sm font-medium"
            data-testid="button-manage-feeds"
          >
            Manage All Feeds <Settings className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
