import { Rss, Clock, CheckCircle, Send } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { DashboardStats } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface StatisticsCardsProps {
  stats: DashboardStats | undefined;
  isLoading: boolean;
}

export function StatisticsCards({ stats, isLoading }: StatisticsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-12" />
                  <Skeleton className="h-4 w-24" />
                </div>
                <Skeleton className="h-12 w-12 rounded-lg" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statCards = [
    {
      label: "Total Feeds",
      value: stats?.totalFeeds || 0,
      change: `+${stats?.activeFeeds || 0} active`,
      icon: Rss,
      color: "primary",
    },
    {
      label: "Pending Review",
      value: stats?.pendingContent || 0,
      change: "Needs attention",
      icon: Clock,
      color: "warning",
    },
    {
      label: "Approved Today",
      value: stats?.approvedToday || 0,
      change: "Ready to post",
      icon: CheckCircle,
      color: "success",
    },
    {
      label: "Posted This Week",
      value: stats?.postedWeek || 0,
      change: "To Telegram",
      icon: Send,
      color: "secondary",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((card, index) => {
        const IconComponent = card.icon;
        return (
          <Card key={index} className="bg-white dark:bg-gray-900 shadow-sm border border-gray-200 dark:border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400" data-testid={`stat-label-${index}`}>
                    {card.label}
                  </p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1" data-testid={`stat-value-${index}`}>
                    {card.value}
                  </p>
                  <p className={`text-sm mt-1 ${
                    card.color === "success" ? "text-success" :
                    card.color === "warning" ? "text-warning" :
                    card.color === "secondary" ? "text-secondary" :
                    "text-success"
                  }`} data-testid={`stat-change-${index}`}>
                    {card.change}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  card.color === "primary" ? "bg-primary/10" :
                  card.color === "warning" ? "bg-warning/10" :
                  card.color === "success" ? "bg-success/10" :
                  "bg-secondary/10"
                }`}>
                  <IconComponent className={`text-xl ${
                    card.color === "primary" ? "text-primary" :
                    card.color === "warning" ? "text-warning" :
                    card.color === "success" ? "text-success" :
                    "text-secondary"
                  }`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
