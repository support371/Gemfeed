import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Rss, 
  FileText, 
  CheckCircle, 
  Settings, 
  Gem 
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: BarChart3, tab: "dashboard" },
  { name: "RSS Feeds", href: "/feeds", icon: Rss, tab: "feeds" },
  { name: "Content Review", href: "/content", icon: FileText, tab: "content" },
  { name: "Approved Content", href: "/approved", icon: CheckCircle, tab: "approved" },
  { name: "Settings", href: "/settings", icon: Settings, tab: "settings" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-white shadow-lg border-r border-gray-200 dark:bg-gray-900 dark:border-gray-700">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gemblue rounded-lg flex items-center justify-center">
            <Gem className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">GEM Enterprise</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">Content Curation</p>
          </div>
        </div>
      </div>
      
      <nav className="mt-6">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center px-6 py-3 text-sm font-medium transition-colors",
                isActive
                  ? "text-gemblue bg-blue-50 border-r-3 border-gemblue dark:bg-blue-900/50 dark:text-blue-300"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"
              )}
              data-testid={`nav-${item.tab}`}
            >
              <item.icon className="mr-3 h-5 w-5" />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </nav>
      
      <div className="absolute bottom-4 left-4 right-4">
        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">System Status</span>
            <span className="status-dot status-active"></span>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400">All feeds operational</p>
        </div>
      </div>
    </div>
  );
}
