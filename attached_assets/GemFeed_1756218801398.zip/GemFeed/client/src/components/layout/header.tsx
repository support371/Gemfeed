import { Bell, Plus, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface HeaderProps {
  title: string;
  subtitle: string;
  onAddFeed?: () => void;
}

export function Header({ title, subtitle, onAddFeed }: HeaderProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const refreshMutation = useMutation({
    mutationFn: api.refreshFeeds,
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Feed refresh initiated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/feed-status"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to refresh feeds",
        variant: "destructive",
      });
    },
  });

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm border-b border-gray-200 dark:border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{title}</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{subtitle}</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            onClick={() => refreshMutation.mutate()}
            disabled={refreshMutation.isPending}
            data-testid="button-refresh-feeds"
            className="bg-secondary hover:bg-teal-600 text-white border-secondary"
          >
            <RefreshCw className={cn("mr-2 h-4 w-4", refreshMutation.isPending && "animate-spin")} />
            Refresh Feeds
          </Button>
          {onAddFeed && (
            <Button
              onClick={onAddFeed}
              data-testid="button-add-feed"
              className="bg-primary hover:bg-indigo-600"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Feed
            </Button>
          )}
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              data-testid="button-notifications"
              className="text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
            >
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 bg-destructive text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                3
              </span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
