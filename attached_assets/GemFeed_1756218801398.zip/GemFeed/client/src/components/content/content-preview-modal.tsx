import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { X, Check, Edit, ExternalLink } from "lucide-react";
import { ContentPreview } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";

interface ContentPreviewModalProps {
  open: boolean;
  onClose: () => void;
  preview: ContentPreview | undefined;
  isLoading: boolean;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onEdit: (id: string, customContent: string) => void;
}

export function ContentPreviewModal({
  open,
  onClose,
  preview,
  isLoading,
  onApprove,
  onReject,
  onEdit,
}: ContentPreviewModalProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState("");

  const handleEdit = () => {
    if (isEditing && preview) {
      onEdit(preview.id, editContent);
      setIsEditing(false);
    } else {
      setEditContent(preview?.customizedContent || preview?.telegramFormat || "");
      setIsEditing(true);
    }
  };

  const handleApprove = () => {
    if (preview) {
      onApprove(preview.id);
      onClose();
    }
  };

  const handleReject = () => {
    if (preview) {
      onReject(preview.id);
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-gray-900 dark:text-white">
            Content Review
          </DialogTitle>
        </DialogHeader>
        
        <div className="overflow-y-auto max-h-[60vh] space-y-6">
          {isLoading ? (
            <div className="space-y-6">
              <Skeleton className="h-8 w-3/4" />
              <div className="flex items-center space-x-4">
                <Skeleton className="h-6 w-20 rounded-full" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-16" />
              </div>
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
          ) : preview ? (
            <>
              {/* Original Content */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3" data-testid="preview-title">
                  {preview.title}
                </h4>
                <div className="flex items-center space-x-4 mb-4">
                  <Badge variant="secondary" className="capitalize" data-testid="preview-category">
                    {preview.category.replace('_', ' ')}
                  </Badge>
                  <span className="text-sm text-gray-500 dark:text-gray-400" data-testid="preview-source">
                    {preview.source}
                  </span>
                  <span className="text-sm text-gray-500 dark:text-gray-400" data-testid="preview-published">
                    {formatDistanceToNow(new Date(preview.published), { addSuffix: true })}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    asChild
                    data-testid="preview-external-link"
                  >
                    <a href={preview.url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed" data-testid="preview-description">
                  {preview.description}
                </p>
              </div>

              {/* AI Summary */}
              {preview.aiSummary && (
                <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                  <h5 className="font-semibold text-gray-900 dark:text-white mb-3">AI Summary</h5>
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                    <p className="text-gray-700 dark:text-gray-300" data-testid="preview-ai-summary">
                      {preview.aiSummary}
                    </p>
                  </div>
                </div>
              )}

              {/* Telegram Preview */}
              <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="font-semibold text-gray-900 dark:text-white">Telegram Post Preview</h5>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleEdit}
                    data-testid="button-edit-telegram"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    {isEditing ? "Save" : "Edit"}
                  </Button>
                </div>
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
                  {isEditing ? (
                    <Textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="font-mono text-sm min-h-[120px]"
                      placeholder="Edit Telegram message format..."
                      data-testid="textarea-edit-telegram"
                    />
                  ) : (
                    <div 
                      className="font-mono text-sm whitespace-pre-wrap"
                      dangerouslySetInnerHTML={{ 
                        __html: (preview.customizedContent || preview.telegramFormat)
                          .replace(/<b>/g, '<strong>')
                          .replace(/<\/b>/g, '</strong>')
                      }}
                      data-testid="preview-telegram-format"
                    />
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">Content not found</p>
            </div>
          )}
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-6 flex justify-end space-x-3">
          <Button
            variant="outline"
            onClick={handleReject}
            disabled={isLoading || !preview}
            data-testid="button-reject-content"
          >
            <X className="mr-2 h-4 w-4" />
            Reject
          </Button>
          <Button
            variant="outline"
            onClick={handleEdit}
            disabled={isLoading || !preview}
            className="bg-warning text-white hover:bg-orange-600 border-warning"
            data-testid="button-edit-content"
          >
            <Edit className="mr-2 h-4 w-4" />
            {isEditing ? "Save Edit" : "Edit"}
          </Button>
          <Button
            onClick={handleApprove}
            disabled={isLoading || !preview}
            className="bg-success text-white hover:bg-green-600"
            data-testid="button-approve-content"
          >
            <Check className="mr-2 h-4 w-4" />
            Approve
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
