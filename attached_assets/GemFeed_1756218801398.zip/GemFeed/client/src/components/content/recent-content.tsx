import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Eye, Shield, TrendingUp, Home } from "lucide-react";
import { ContentItem } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";

interface RecentContentProps {
  content: ContentItem[] | undefined;
  isLoading: boolean;
  onViewAll: () => void;
  onReviewContent: (id: string) => void;
}

const categoryIcons = {
  cybersecurity: Shield,
  financial: TrendingUp,
  real_estate: Home,
  general: Eye,
};

const statusColors = {
  pending: "bg-warning/10 text-warning",
  approved: "bg-success/10 text-success",
  rejected: "bg-destructive/10 text-destructive",
  posted: "bg-primary/10 text-primary",
};

export function RecentContent({ content, isLoading, onViewAll, onReviewContent }: RecentContentProps) {
  if (isLoading) {
    return (
      <Card className="lg:col-span-2">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Content</CardTitle>
            <Skeleton className="h-6 w-16" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-start space-x-4 py-4">
                <Skeleton className="w-10 h-10 rounded-lg" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/4" />
                  <div className="flex items-center space-x-2">
                    <Skeleton className="h-5 w-16 rounded-full" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                </div>
                <Skeleton className="w-6 h-6" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="lg:col-span-2 bg-white dark:bg-gray-900 shadow-sm border border-gray-200 dark:border-gray-700">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
            Recent Content
          </CardTitle>
          <Button
            variant="ghost"
            onClick={onViewAll}
            className="text-primary hover:text-indigo-600 text-sm font-medium"
            data-testid="button-view-all-content"
          >
            View All <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {content?.slice(0, 5).map((item) => {
            const CategoryIcon = categoryIcons[item.category as keyof typeof categoryIcons] || Eye;
            return (
              <div
                key={item.id}
                className="flex items-start space-x-4 py-4 border-b border-gray-100 dark:border-gray-700 last:border-b-0"
                data-testid={`content-item-${item.id}`}
              >
                <div className="flex-shrink-0">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    item.category === "cybersecurity" ? "bg-primary/10" :
                    item.category === "financial" ? "bg-secondary/10" :
                    item.category === "real_estate" ? "bg-purple-100" :
                    "bg-gray-100"
                  }`}>
                    <CategoryIcon className={`h-5 w-5 ${
                      item.category === "cybersecurity" ? "text-primary" :
                      item.category === "financial" ? "text-secondary" :
                      item.category === "real_estate" ? "text-purple-600" :
                      "text-gray-600"
                    }`} />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 dark:text-white truncate" data-testid={`content-title-${item.id}`}>
                    {item.title}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400" data-testid={`content-source-${item.id}`}>
                    {item.source}
                  </p>
                  <div className="flex items-center mt-2">
                    <Badge
                      variant="secondary"
                      className={statusColors[item.status as keyof typeof statusColors]}
                      data-testid={`content-status-${item.id}`}
                    >
                      {item.status}
                    </Badge>
                    <span className="text-xs text-gray-400 dark:text-gray-500 ml-3" data-testid={`content-time-${item.id}`}>
                      {formatDistanceToNow(new Date(item.published), { addSuffix: true })}
                    </span>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onReviewContent(item.id)}
                    className="text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
                    data-testid={`button-review-${item.id}`}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
