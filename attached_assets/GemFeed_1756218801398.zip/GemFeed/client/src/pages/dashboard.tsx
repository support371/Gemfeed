import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { StatisticsCards } from "@/components/stats/statistics-cards";
import { RecentContent } from "@/components/content/recent-content";
import { FeedStatusPanel } from "@/components/feeds/feed-status-panel";
import { ContentPreviewModal } from "@/components/content/content-preview-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  CheckCheck, 
  Download, 
  Clock, 
  BarChart3 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedContentId, setSelectedContentId] = useState<string | null>(null);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: api.getDashboardStats,
  });

  const { data: feedStatus, isLoading: feedStatusLoading } = useQuery({
    queryKey: ["/api/dashboard/feed-status"],
    queryFn: api.getFeedStatus,
  });

  const { data: recentContent, isLoading: contentLoading } = useQuery({
    queryKey: ["/api/content", { limit: 10 }],
    queryFn: () => api.getContent({ limit: 10 }),
  });

  const { data: contentPreview, isLoading: previewLoading } = useQuery({
    queryKey: ["/api/content", selectedContentId, "preview"],
    queryFn: () => selectedContentId ? api.getContentPreview(selectedContentId) : null,
    enabled: !!selectedContentId,
  });

  const approveMutation = useMutation({
    mutationFn: api.approveContent,
    onSuccess: () => {
      toast({
        title: "Content Approved",
        description: "Content has been approved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve content",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: api.rejectContent,
    onSuccess: () => {
      toast({
        title: "Content Rejected",
        description: "Content has been rejected",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reject content",
        variant: "destructive",
      });
    },
  });

  const bulkApproveMutation = useMutation({
    mutationFn: api.bulkApproveContent,
    onSuccess: (data: any) => {
      toast({
        title: "Bulk Approval Complete",
        description: `${data?.length || 0} items approved successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to bulk approve content",
        variant: "destructive",
      });
    },
  });

  const exportMutation = useMutation({
    mutationFn: api.exportContent,
    onSuccess: (data: any) => {
      toast({
        title: "Export Complete",
        description: `${data?.count || 0} items exported successfully`,
      });
      // Create and download file
      const blob = new Blob([JSON.stringify(data?.data || [], null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `content-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to export content",
        variant: "destructive",
      });
    },
  });

  const handleReviewContent = (id: string) => {
    setSelectedContentId(id);
  };

  const handleCloseModal = () => {
    setSelectedContentId(null);
  };

  const handleBulkApprove = () => {
    const pendingIds = recentContent?.filter((item: any) => item.status === "pending").slice(0, 5).map((item: any) => item.id) || [];
    if (pendingIds.length > 0) {
      bulkApproveMutation.mutate(pendingIds);
    } else {
      toast({
        title: "No Content",
        description: "No pending content available for bulk approval",
      });
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Dashboard Overview"
        subtitle="Monitor RSS feeds and content curation performance"
        onAddFeed={() => setLocation("/feeds")}
      />

      <main className="flex-1 overflow-y-auto p-6">
        <StatisticsCards stats={stats} isLoading={statsLoading} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <RecentContent
            content={recentContent}
            isLoading={contentLoading}
            onViewAll={() => setLocation("/content")}
            onReviewContent={handleReviewContent}
          />

          <FeedStatusPanel
            feedStatus={feedStatus}
            isLoading={feedStatusLoading}
            onManageFeeds={() => setLocation("/feeds")}
          />
        </div>

        {/* Quick Actions Bar */}
        <Card className="bg-white dark:bg-gray-900 shadow-sm border border-gray-200 dark:border-gray-700">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button
                variant="outline"
                onClick={handleBulkApprove}
                disabled={bulkApproveMutation.isPending}
                className="flex items-center justify-center p-4 h-auto"
                data-testid="button-bulk-approve"
              >
                <CheckCheck className="text-success mr-3 h-6 w-6" />
                <span className="font-medium">Bulk Approve</span>
              </Button>
              
              <Button
                variant="outline"
                onClick={() => exportMutation.mutate("approved")}
                disabled={exportMutation.isPending}
                className="flex items-center justify-center p-4 h-auto"
                data-testid="button-export-content"
              >
                <Download className="text-primary mr-3 h-6 w-6" />
                <span className="font-medium">Export Content</span>
              </Button>
              
              <Button
                variant="outline"
                onClick={() => setLocation("/approved")}
                className="flex items-center justify-center p-4 h-auto"
                data-testid="button-schedule-posts"
              >
                <Clock className="text-secondary mr-3 h-6 w-6" />
                <span className="font-medium">Schedule Posts</span>
              </Button>
              
              <Button
                variant="outline"
                onClick={() => toast({ title: "Coming Soon", description: "Analytics feature coming soon" })}
                className="flex items-center justify-center p-4 h-auto"
                data-testid="button-view-analytics"
              >
                <BarChart3 className="text-warning mr-3 h-6 w-6" />
                <span className="font-medium">View Analytics</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        <ContentPreviewModal
          open={!!selectedContentId}
          onClose={handleCloseModal}
          preview={contentPreview}
          isLoading={previewLoading}
          onApprove={(id) => approveMutation.mutate(id)}
          onReject={(id) => rejectMutation.mutate(id)}
          onEdit={(id, customContent) => {
            // TODO: Implement content editing
            toast({ title: "Coming Soon", description: "Content editing feature coming soon" });
          }}
        />
      </main>
    </div>
  );
}
