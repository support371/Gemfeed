import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { ContentPreviewModal } from "@/components/content/content-preview-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Eye, Search, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { ContentItem } from "@shared/schema";

export default function ContentReview() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("pending");
  const [selectedContentId, setSelectedContentId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: content, isLoading } = useQuery({
    queryKey: ["/api/content", { status: selectedStatus !== "all" ? selectedStatus : undefined, category: selectedCategory !== "all" ? selectedCategory : undefined }],
    queryFn: () => api.getContent({
      status: selectedStatus !== "all" ? selectedStatus : undefined,
      category: selectedCategory !== "all" ? selectedCategory : undefined,
    }),
  });

  const { data: contentPreview, isLoading: previewLoading } = useQuery({
    queryKey: ["/api/content", selectedContentId, "preview"],
    queryFn: () => selectedContentId ? api.getContentPreview(selectedContentId) : null,
    enabled: !!selectedContentId,
  });

  const approveMutation = useMutation({
    mutationFn: api.approveContent,
    onSuccess: () => {
      toast({
        title: "Content Approved",
        description: "Content has been approved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve content",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: api.rejectContent,
    onSuccess: () => {
      toast({
        title: "Content Rejected",
        description: "Content has been rejected",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reject content",
        variant: "destructive",
      });
    },
  });

  const filteredContent = content?.filter((item: ContentItem) => {
    const matchesSearch = searchTerm === "" || 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.source.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const handleReviewContent = (id: string) => {
    setSelectedContentId(id);
  };

  const handleCloseModal = () => {
    setSelectedContentId(null);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-warning/10 text-warning";
      case "approved":
        return "bg-success/10 text-success";
      case "rejected":
        return "bg-destructive/10 text-destructive";
      case "posted":
        return "bg-primary/10 text-primary";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "cybersecurity":
        return "bg-primary/10 text-primary";
      case "financial":
        return "bg-secondary/10 text-secondary";
      case "real_estate":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Content Review"
        subtitle="Review and approve content for Telegram publishing"
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search content..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-content"
                  />
                </div>
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48" data-testid="select-category-filter">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="cybersecurity">Cybersecurity</SelectItem>
                  <SelectItem value="financial">Financial</SelectItem>
                  <SelectItem value="real_estate">Real Estate</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-48" data-testid="select-status-filter">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="posted">Posted</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Content List */}
        <div className="space-y-4">
          {isLoading ? (
            [...Array(5)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="animate-pulse space-y-4">
                    <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                    <div className="flex space-x-2">
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-20"></div>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-16"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredContent?.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Filter className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">No Content Found</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  {searchTerm || selectedCategory !== "all" || selectedStatus !== "all"
                    ? "Try adjusting your filters or search terms."
                    : "No content available for review at the moment."}
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredContent?.map((item: any) => (
              <Card key={item.id} className="content-card bg-white dark:bg-gray-900 hover:shadow-lg transition-all duration-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2" data-testid={`content-title-${item.id}`}>
                        {item.title}
                      </h3>
                      
                      <p className="text-gray-600 dark:text-gray-300 mb-3 line-clamp-2" data-testid={`content-description-${item.id}`}>
                        {item.description}
                      </p>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400 mb-3">
                        <span data-testid={`content-source-${item.id}`}>{item.source}</span>
                        <span data-testid={`content-published-${item.id}`}>
                          {formatDistanceToNow(new Date(item.published), { addSuffix: true })}
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Badge className={getCategoryColor(item.category)} data-testid={`content-category-${item.id}`}>
                          {item.category.replace("_", " ")}
                        </Badge>
                        <Badge className={getStatusColor(item.status)} data-testid={`content-status-${item.id}`}>
                          {item.status}
                        </Badge>
                        {item.tags?.slice(0, 2).map((tag: string, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleReviewContent(item.id)}
                        data-testid={`button-review-${item.id}`}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Review
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        <ContentPreviewModal
          open={!!selectedContentId}
          onClose={handleCloseModal}
          preview={contentPreview}
          isLoading={previewLoading}
          onApprove={(id) => approveMutation.mutate(id)}
          onReject={(id) => rejectMutation.mutate(id)}
          onEdit={(id, customContent) => {
            // TODO: Implement content editing
            toast({ title: "Coming Soon", description: "Content editing feature coming soon" });
          }}
        />
      </main>
    </div>
  );
}
