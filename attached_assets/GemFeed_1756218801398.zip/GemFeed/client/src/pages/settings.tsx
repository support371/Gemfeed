import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  Bot, 
  Bell, 
  Database, 
  Palette, 
  Save,
  TestTube,
  Users,
  MessageSquare
} from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [autoApproval, setAutoApproval] = useState(true);
  const [notificationSettings, setNotificationSettings] = useState({
    feedErrors: true,
    contentApproval: true,
    dailyDigest: true,
  });

  const [aiSettings, setAiSettings] = useState({
    provider: "openai",
    summaryLength: 200,
    autoSummarize: true,
    customPrompt: "",
  });

  const [telegramSettings, setTelegramSettings] = useState({
    botToken: "",
    defaultChannel: "",
    channelMappings: {
      cybersecurity: "security,cybergemsecure",
      financial: "client,gemassist",
      real_estate: "realestate",
      general: "client"
    },
    messageTemplate: `🔔 <b>{title}</b>

📰 {summary}

🏷️ #{category} #{source}
🔗 Read more: {url}

💎 Powered by GEM Enterprise`,
  });

  const handleSaveGeneral = () => {
    toast({
      title: "Settings Saved",
      description: "General settings have been updated successfully",
    });
  };

  const handleSaveAI = () => {
    toast({
      title: "AI Settings Saved",
      description: "AI configuration has been updated successfully",
    });
  };

  const handleSaveTelegram = () => {
    toast({
      title: "Telegram Settings Saved",
      description: "Telegram integration has been configured successfully",
    });
  };

  const handleTestConnection = (service: string) => {
    toast({
      title: "Testing Connection",
      description: `Testing ${service} connection...`,
    });
    
    // Simulate test
    setTimeout(() => {
      toast({
        title: "Connection Test",
        description: `${service} connection test completed successfully`,
      });
    }, 2000);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Settings"
        subtitle="Configure system preferences and integrations"
      />

      <main className="flex-1 overflow-y-auto p-6">
        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="general" className="flex items-center gap-2" data-testid="tab-general">
              <SettingsIcon className="h-4 w-4" />
              General
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center gap-2" data-testid="tab-ai">
              <Bot className="h-4 w-4" />
              AI & ML
            </TabsTrigger>
            <TabsTrigger value="telegram" className="flex items-center gap-2" data-testid="tab-telegram">
              <MessageSquare className="h-4 w-4" />
              Telegram
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2" data-testid="tab-notifications">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center gap-2" data-testid="tab-system">
              <Database className="h-4 w-4" />
              System
            </TabsTrigger>
          </TabsList>

          {/* General Settings */}
          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Appearance & Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Dark Mode</Label>
                    <p className="text-sm text-muted-foreground">
                      Toggle between light and dark themes
                    </p>
                  </div>
                  <Switch
                    checked={isDarkMode}
                    onCheckedChange={setIsDarkMode}
                    data-testid="switch-dark-mode"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Auto-Approval</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically approve content from trusted sources
                    </p>
                  </div>
                  <Switch
                    checked={autoApproval}
                    onCheckedChange={setAutoApproval}
                    data-testid="switch-auto-approval"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="refresh-interval">Feed Refresh Interval (minutes)</Label>
                  <Select defaultValue="60">
                    <SelectTrigger data-testid="select-refresh-interval">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="120">2 hours</SelectItem>
                      <SelectItem value="240">4 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content-retention">Content Retention (days)</Label>
                  <Input
                    id="content-retention"
                    type="number"
                    defaultValue="30"
                    min="1"
                    max="365"
                    data-testid="input-content-retention"
                  />
                  <p className="text-sm text-muted-foreground">
                    How long to keep content items before automatic cleanup
                  </p>
                </div>

                <Button onClick={handleSaveGeneral} data-testid="button-save-general">
                  <Save className="h-4 w-4 mr-2" />
                  Save General Settings
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Trusted Sources</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">Reuters Finance</Badge>
                    <Badge variant="secondary">Bloomberg Markets</Badge>
                    <Badge variant="secondary">CISA Alerts</Badge>
                    <Badge variant="secondary">Krebs on Security</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Content from these sources will be automatically approved when auto-approval is enabled
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Settings */}
          <TabsContent value="ai" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="h-5 w-5" />
                  AI Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="ai-provider">AI Provider</Label>
                  <Select value={aiSettings.provider} onValueChange={(value) => 
                    setAiSettings(prev => ({ ...prev, provider: value }))
                  }>
                    <SelectTrigger data-testid="select-ai-provider">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="openai">OpenAI GPT</SelectItem>
                      <SelectItem value="anthropic">Anthropic Claude</SelectItem>
                      <SelectItem value="perplexity">Perplexity AI</SelectItem>
                      <SelectItem value="local">Local Model</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key</Label>
                  <Input
                    id="api-key"
                    type="password"
                    placeholder="Enter your AI provider API key"
                    data-testid="input-ai-api-key"
                  />
                  <p className="text-sm text-muted-foreground">
                    Your API key will be securely stored and encrypted
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="summary-length">Summary Length (characters)</Label>
                  <Input
                    id="summary-length"
                    type="number"
                    value={aiSettings.summaryLength}
                    onChange={(e) => setAiSettings(prev => ({ 
                      ...prev, 
                      summaryLength: parseInt(e.target.value) 
                    }))}
                    min="50"
                    max="500"
                    data-testid="input-summary-length"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Auto-Summarize</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically generate AI summaries for new content
                    </p>
                  </div>
                  <Switch
                    checked={aiSettings.autoSummarize}
                    onCheckedChange={(checked) => 
                      setAiSettings(prev => ({ ...prev, autoSummarize: checked }))
                    }
                    data-testid="switch-auto-summarize"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="custom-prompt">Custom Summarization Prompt</Label>
                  <Textarea
                    id="custom-prompt"
                    placeholder="Enter custom prompt for AI summarization..."
                    value={aiSettings.customPrompt}
                    onChange={(e) => setAiSettings(prev => ({ 
                      ...prev, 
                      customPrompt: e.target.value 
                    }))}
                    rows={4}
                    data-testid="textarea-custom-prompt"
                  />
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleSaveAI} data-testid="button-save-ai">
                    <Save className="h-4 w-4 mr-2" />
                    Save AI Settings
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleTestConnection("AI")}
                    data-testid="button-test-ai"
                  >
                    <TestTube className="h-4 w-4 mr-2" />
                    Test Connection
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Telegram Settings */}
          <TabsContent value="telegram" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Telegram Bot Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="bot-token">Bot Token</Label>
                  <Input
                    id="bot-token"
                    type="password"
                    placeholder="Enter your Telegram bot token"
                    value={telegramSettings.botToken}
                    onChange={(e) => setTelegramSettings(prev => ({ 
                      ...prev, 
                      botToken: e.target.value 
                    }))}
                    data-testid="input-bot-token"
                  />
                  <p className="text-sm text-muted-foreground">
                    Get your bot token from @BotFather on Telegram
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="default-channel">Default Channel</Label>
                  <Input
                    id="default-channel"
                    placeholder="@your_channel or channel_id"
                    value={telegramSettings.defaultChannel}
                    onChange={(e) => setTelegramSettings(prev => ({ 
                      ...prev, 
                      defaultChannel: e.target.value 
                    }))}
                    data-testid="input-default-channel"
                  />
                </div>

                <div className="space-y-4">
                  <Label>Channel Mappings</Label>
                  {Object.entries(telegramSettings.channelMappings).map(([category, channels]) => (
                    <div key={category} className="space-y-2">
                      <Label className="capitalize">{category.replace('_', ' ')}</Label>
                      <Input
                        placeholder="channel1,channel2,channel3"
                        value={channels}
                        onChange={(e) => setTelegramSettings(prev => ({
                          ...prev,
                          channelMappings: {
                            ...prev.channelMappings,
                            [category]: e.target.value
                          }
                        }))}
                        data-testid={`input-channels-${category}`}
                      />
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message-template">Message Template</Label>
                  <Textarea
                    id="message-template"
                    rows={8}
                    value={telegramSettings.messageTemplate}
                    onChange={(e) => setTelegramSettings(prev => ({ 
                      ...prev, 
                      messageTemplate: e.target.value 
                    }))}
                    data-testid="textarea-message-template"
                  />
                  <p className="text-sm text-muted-foreground">
                    Available variables: {"{title}, {summary}, {category}, {source}, {url}"}
                  </p>
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleSaveTelegram} data-testid="button-save-telegram">
                    <Save className="h-4 w-4 mr-2" />
                    Save Telegram Settings
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleTestConnection("Telegram")}
                    data-testid="button-test-telegram"
                  >
                    <TestTube className="h-4 w-4 mr-2" />
                    Test Bot Connection
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Feed Error Alerts</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified when RSS feeds fail to update
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.feedErrors}
                    onCheckedChange={(checked) => 
                      setNotificationSettings(prev => ({ ...prev, feedErrors: checked }))
                    }
                    data-testid="switch-feed-errors"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Content Approval</Label>
                    <p className="text-sm text-muted-foreground">
                      Get notified when content needs approval
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.contentApproval}
                    onCheckedChange={(checked) => 
                      setNotificationSettings(prev => ({ ...prev, contentApproval: checked }))
                    }
                    data-testid="switch-content-approval"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Daily Digest</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive daily summary of system activity
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.dailyDigest}
                    onCheckedChange={(checked) => 
                      setNotificationSettings(prev => ({ ...prev, dailyDigest: checked }))
                    }
                    data-testid="switch-daily-digest"
                  />
                </div>

                <Button onClick={handleSaveGeneral} data-testid="button-save-notifications">
                  <Save className="h-4 w-4 mr-2" />
                  Save Notification Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Settings */}
          <TabsContent value="system" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  System Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Version</Label>
                    <p className="text-lg font-semibold">v1.0.0</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Last Updated</Label>
                    <p className="text-lg font-semibold">Today</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Active Feeds</Label>
                    <p className="text-lg font-semibold">24</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Total Content</Label>
                    <p className="text-lg font-semibold">1,247</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Button variant="outline" data-testid="button-clear-cache">
                    Clear Cache
                  </Button>
                  <Button variant="outline" data-testid="button-export-settings">
                    Export Settings
                  </Button>
                  <Button variant="outline" data-testid="button-import-settings">
                    Import Settings
                  </Button>
                </div>
                <div className="pt-4 border-t">
                  <Button 
                    variant="destructive" 
                    onClick={() => toast({ 
                      title: "Confirmation Required", 
                      description: "This action would reset all settings to defaults" 
                    })}
                    data-testid="button-reset-settings"
                  >
                    Reset to Defaults
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
