import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Send, Search, Calendar, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { ContentItem } from "@shared/schema";

export default function ApprovedContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const { toast } = useToast();

  const { data: content, isLoading } = useQuery({
    queryKey: ["/api/content", { status: "approved", category: selectedCategory !== "all" ? selectedCategory : undefined }],
    queryFn: () => api.getContent({
      status: "approved",
      category: selectedCategory !== "all" ? selectedCategory : undefined,
    }),
  });

  const filteredContent = content?.filter((item: ContentItem) => {
    const matchesSearch = searchTerm === "" || 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.source.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "cybersecurity":
        return "bg-primary/10 text-primary";
      case "financial":
        return "bg-secondary/10 text-secondary";
      case "real_estate":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  const handleSchedulePost = (id: string) => {
    toast({
      title: "Coming Soon",
      description: "Post scheduling feature will be available soon",
    });
  };

  const handlePostNow = (id: string) => {
    toast({
      title: "Coming Soon",
      description: "Telegram posting integration will be available soon",
    });
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Approved Content"
        subtitle="Ready-to-post content for Telegram channels"
      />

      <main className="flex-1 overflow-y-auto p-6">
        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search approved content..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                    data-testid="input-search-approved"
                  />
                </div>
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48" data-testid="select-category-filter">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="cybersecurity">Cybersecurity</SelectItem>
                  <SelectItem value="financial">Financial</SelectItem>
                  <SelectItem value="real_estate">Real Estate</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Content List */}
        <div className="space-y-4">
          {isLoading ? (
            [...Array(5)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="animate-pulse space-y-4">
                    <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                    <div className="flex space-x-2">
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-20"></div>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-16"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredContent?.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">No Approved Content</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  No approved content available for posting at the moment.
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredContent?.map((item: any) => (
              <Card key={item.id} className="bg-white dark:bg-gray-900">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2" data-testid={`approved-title-${item.id}`}>
                        {item.title}
                      </h3>
                      
                      <p className="text-gray-600 dark:text-gray-300 mb-3 line-clamp-2" data-testid={`approved-description-${item.id}`}>
                        {item.description}
                      </p>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400 mb-3">
                        <span data-testid={`approved-source-${item.id}`}>{item.source}</span>
                        <span data-testid={`approved-published-${item.id}`}>
                          {formatDistanceToNow(new Date(item.published), { addSuffix: true })}
                        </span>
                        {item.reviewedAt && (
                          <span data-testid={`approved-reviewed-${item.id}`}>
                            Approved {formatDistanceToNow(new Date(item.reviewedAt), { addSuffix: true })}
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-2 mb-3">
                        <Badge className={getCategoryColor(item.category)} data-testid={`approved-category-${item.id}`}>
                          {item.category.replace("_", " ")}
                        </Badge>
                        <Badge className="bg-success/10 text-success">
                          Approved
                        </Badge>
                        {item.telegramChannels?.map((channel: string, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            #{channel}
                          </Badge>
                        ))}
                      </div>

                      {item.aiSummary && (
                        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 mb-3">
                          <p className="text-sm text-gray-700 dark:text-gray-300" data-testid={`approved-summary-${item.id}`}>
                            <strong>AI Summary:</strong> {item.aiSummary}
                          </p>
                        </div>
                      )}

                      <div className="flex items-center space-x-2 text-sm">
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                        >
                          <a 
                            href={item.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            data-testid={`approved-link-${item.id}`}
                          >
                            <ExternalLink className="h-4 w-4 mr-2" />
                            View Original
                          </a>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="ml-4 flex flex-col space-y-2">
                      <Button
                        onClick={() => handlePostNow(item.id)}
                        className="bg-secondary hover:bg-teal-600"
                        data-testid={`button-post-now-${item.id}`}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Post Now
                      </Button>
                      
                      <Button
                        variant="outline"
                        onClick={() => handleSchedulePost(item.id)}
                        data-testid={`button-schedule-${item.id}`}
                      >
                        <Calendar className="h-4 w-4 mr-2" />
                        Schedule
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
}
