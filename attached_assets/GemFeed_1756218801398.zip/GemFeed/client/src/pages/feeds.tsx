import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertRssFeedSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { Trash2, ExternalLink, AlertCircle } from "lucide-react";
import { z } from "zod";

const formSchema = insertRssFeedSchema.extend({
  category: z.enum(["cybersecurity", "financial", "real_estate", "general"]),
});

type FormData = z.infer<typeof formSchema>;

export default function Feeds() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: feeds, isLoading } = useQuery({
    queryKey: ["/api/feeds"],
    queryFn: api.getFeeds,
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      url: "",
      category: "general",
      enabled: true,
      updateFrequency: 3600,
    },
  });

  const createMutation = useMutation({
    mutationFn: api.createFeed,
    onSuccess: () => {
      toast({
        title: "Feed Added",
        description: "RSS feed has been added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/feeds"] });
      setIsAddModalOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add RSS feed",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => api.updateFeed(id, data),
    onSuccess: () => {
      toast({
        title: "Feed Updated",
        description: "RSS feed has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/feeds"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update RSS feed",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: api.deleteFeed,
    onSuccess: () => {
      toast({
        title: "Feed Deleted",
        description: "RSS feed has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/feeds"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete RSS feed",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    createMutation.mutate(data);
  };

  const toggleFeedEnabled = (id: string, enabled: boolean) => {
    updateMutation.mutate({ id, data: { enabled } });
  };

  const handleDeleteFeed = (id: string) => {
    if (confirm("Are you sure you want to delete this RSS feed?")) {
      deleteMutation.mutate(id);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "cybersecurity":
        return "bg-primary/10 text-primary";
      case "financial":
        return "bg-secondary/10 text-secondary";
      case "real_estate":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-success/10 text-success";
      case "error":
        return "bg-destructive/10 text-destructive";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300";
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="RSS Feed Management"
        subtitle="Manage and monitor your RSS feed sources"
        onAddFeed={() => setIsAddModalOpen(true)}
      />

      <main className="flex-1 overflow-y-auto p-6">
        <div className="grid gap-6">
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <div className="animate-pulse space-y-4">
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-2/3"></div>
                      <div className="flex space-x-2">
                        <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-20"></div>
                        <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-16"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            feeds?.map((feed: any) => (
              <Card key={feed.id} className="bg-white dark:bg-gray-900">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white" data-testid={`feed-name-${feed.id}`}>
                          {feed.name}
                        </h3>
                        <Badge className={getCategoryColor(feed.category)} data-testid={`feed-category-${feed.id}`}>
                          {feed.category.replace("_", " ")}
                        </Badge>
                        <Badge className={getStatusColor(feed.status)} data-testid={`feed-status-${feed.id}`}>
                          {feed.status}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400 mb-2">
                        <a
                          href={feed.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center hover:text-primary"
                          data-testid={`feed-url-${feed.id}`}
                        >
                          <ExternalLink className="h-4 w-4 mr-1" />
                          {feed.url}
                        </a>
                        {feed.lastUpdated && (
                          <span data-testid={`feed-last-updated-${feed.id}`}>
                            Last updated: {formatDistanceToNow(new Date(feed.lastUpdated), { addSuffix: true })}
                          </span>
                        )}
                      </div>

                      {feed.status === "error" && feed.errorMessage && (
                        <div className="flex items-center text-destructive text-sm mt-2" data-testid={`feed-error-${feed.id}`}>
                          <AlertCircle className="h-4 w-4 mr-2" />
                          {feed.errorMessage}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-500 dark:text-gray-400">Enabled</span>
                        <Switch
                          checked={feed.enabled}
                          onCheckedChange={(enabled) => toggleFeedEnabled(feed.id, enabled)}
                          disabled={updateMutation.isPending}
                          data-testid={`feed-toggle-${feed.id}`}
                        />
                      </div>
                      
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteFeed(feed.id)}
                        disabled={deleteMutation.isPending}
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        data-testid={`feed-delete-${feed.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Add Feed Modal */}
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add RSS Feed</DialogTitle>
              <DialogDescription>
                Add a new RSS feed source to your content aggregation system.
              </DialogDescription>
            </DialogHeader>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Feed Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Krebs on Security" 
                          {...field} 
                          data-testid="input-feed-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>RSS URL</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://example.com/feed.xml" 
                          type="url" 
                          {...field} 
                          data-testid="input-feed-url"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-feed-category">
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="cybersecurity">Cybersecurity</SelectItem>
                          <SelectItem value="financial">Financial</SelectItem>
                          <SelectItem value="real_estate">Real Estate</SelectItem>
                          <SelectItem value="general">General</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="updateFrequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Update Frequency (seconds)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="300" 
                          max="86400" 
                          {...field}
                          value={field.value || ""}
                          onChange={e => field.onChange(parseInt(e.target.value))}
                          data-testid="input-feed-frequency"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddModalOpen(false)}
                    data-testid="button-cancel-feed"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createMutation.isPending}
                    data-testid="button-save-feed"
                  >
                    {createMutation.isPending ? "Adding..." : "Add Feed"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
