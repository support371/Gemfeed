import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRssFeedSchema, insertContentItemSchema } from "@shared/schema";
import { z } from "zod";
import { RSSParser } from "./services/rss-parser";
import { TelegramService } from "./services/telegram-bot";
import { AIService } from "./services/ai-service";

// Initialize services
const rssParser = new RSSParser();
const telegramService = new TelegramService();
let aiService: AIService | null = null;

export async function registerRoutes(app: Express): Promise<Server> {
  // RSS Feeds routes
  app.get("/api/feeds", async (req, res) => {
    try {
      const feeds = await storage.getRssFeeds();
      res.json(feeds);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch feeds" });
    }
  });

  app.get("/api/feeds/:id", async (req, res) => {
    try {
      const feed = await storage.getRssFeed(req.params.id);
      if (!feed) {
        return res.status(404).json({ message: "Feed not found" });
      }
      res.json(feed);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch feed" });
    }
  });

  app.post("/api/feeds", async (req, res) => {
    try {
      const validatedData = insertRssFeedSchema.parse(req.body);
      const feed = await storage.createRssFeed(validatedData);
      res.status(201).json(feed);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid feed data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create feed" });
    }
  });

  app.put("/api/feeds/:id", async (req, res) => {
    try {
      const feed = await storage.updateRssFeed(req.params.id, req.body);
      if (!feed) {
        return res.status(404).json({ message: "Feed not found" });
      }
      res.json(feed);
    } catch (error) {
      res.status(500).json({ message: "Failed to update feed" });
    }
  });

  app.delete("/api/feeds/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteRssFeed(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Feed not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete feed" });
    }
  });

  // Content routes
  app.get("/api/content", async (req, res) => {
    try {
      const { status, category, limit } = req.query;
      const content = await storage.getContentItems(
        status as string,
        category as string,
        limit ? parseInt(limit as string) : undefined
      );
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  app.get("/api/content/:id", async (req, res) => {
    try {
      const content = await storage.getContentItem(req.params.id);
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  app.get("/api/content/:id/preview", async (req, res) => {
    try {
      const preview = await storage.getContentPreview(req.params.id);
      if (!preview) {
        return res.status(404).json({ message: "Content not found" });
      }
      res.json(preview);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content preview" });
    }
  });

  app.put("/api/content/:id", async (req, res) => {
    try {
      const content = await storage.updateContentItem(req.params.id, req.body);
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to update content" });
    }
  });

  app.post("/api/content/:id/approve", async (req, res) => {
    try {
      const content = await storage.updateContentItem(req.params.id, {
        status: "approved",
        reviewedBy: "admin", // TODO: Get from auth context
        reviewedAt: new Date(),
      });
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to approve content" });
    }
  });

  app.post("/api/content/:id/reject", async (req, res) => {
    try {
      const content = await storage.updateContentItem(req.params.id, {
        status: "rejected",
        reviewedBy: "admin", // TODO: Get from auth context
        reviewedAt: new Date(),
      });
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to reject content" });
    }
  });

  app.post("/api/content/bulk-approve", async (req, res) => {
    try {
      const { ids } = req.body;
      if (!Array.isArray(ids)) {
        return res.status(400).json({ message: "Invalid request: ids must be an array" });
      }

      const results = [];
      for (const id of ids) {
        const content = await storage.updateContentItem(id, {
          status: "approved",
          reviewedBy: "admin",
          reviewedAt: new Date(),
        });
        if (content) {
          results.push(content);
        }
      }

      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to bulk approve content" });
    }
  });

  // Dashboard routes
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get("/api/dashboard/feed-status", async (req, res) => {
    try {
      const status = await storage.getFeedStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch feed status" });
    }
  });

  // Workflow routes
  app.post("/api/workflow/refresh-feeds", async (req, res) => {
    try {
      const feeds = await storage.getRssFeeds();
      const activeFeedUrls = feeds
        .filter(feed => feed.isActive)
        .map(feed => ({
          url: feed.url,
          name: feed.name,
          category: feed.category
        }));

      if (activeFeedUrls.length === 0) {
        return res.json({ message: "No active feeds to refresh" });
      }

      const items = await rssParser.fetchAndStoreFeeds(activeFeedUrls);
      
      // Store new content items
      let newItemsCount = 0;
      for (const item of items) {
        try {
          await storage.createContentItem({
            id: `rss-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            source: item.source || 'Unknown',
            title: item.title,
            content: item.summary,
            description: item.summary,
            url: item.link,
            category: item.category || 'general',
            published: item.pubDate,
            tags: item.categories || [],
            status: 'pending'
          });
          newItemsCount++;
        } catch (error) {
          console.error('Error storing content item:', error);
        }
      }

      await storage.createWorkflowLog({
        type: "fetch",
        status: "success",
        message: `RSS refresh completed. ${newItemsCount} new items added.`,
        metadata: { 
          timestamp: new Date().toISOString(),
          feedsProcessed: activeFeedUrls.length,
          itemsAdded: newItemsCount
        },
      });

      res.json({ 
        message: "Feed refresh completed", 
        feedsProcessed: activeFeedUrls.length,
        newItems: newItemsCount 
      });
    } catch (error) {
      console.error('RSS refresh error:', error);
      await storage.createWorkflowLog({
        type: "fetch",
        status: "error",
        message: `RSS refresh failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        metadata: { timestamp: new Date().toISOString() },
      });
      res.status(500).json({ message: "Failed to refresh feeds" });
    }
  });

  app.post("/api/workflow/export-content", async (req, res) => {
    try {
      const { status = "approved" } = req.body;
      const content = await storage.getContentItems(status);
      
      res.json({
        message: "Content exported successfully",
        count: content.length,
        data: content,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to export content" });
    }
  });

  // AI Service routes
  app.post("/api/ai/generate-summary", async (req, res) => {
    try {
      const { title, content, category } = req.body;
      
      if (!aiService) {
        return res.status(400).json({ message: "AI service not configured" });
      }

      const summary = await aiService.generateSummary({ title, content, category });
      
      res.json({ summary });
    } catch (error) {
      console.error('AI summary generation error:', error);
      res.status(500).json({ message: "Failed to generate AI summary" });
    }
  });

  app.post("/api/ai/configure", async (req, res) => {
    try {
      const { provider, apiKey, model, customPrompt } = req.body;
      
      aiService = new AIService({
        provider,
        apiKey,
        model,
        customPrompt
      });

      const connected = await aiService.testConnection();
      
      if (connected) {
        res.json({ message: "AI service configured successfully" });
      } else {
        res.status(400).json({ message: "Failed to connect to AI service" });
      }
    } catch (error) {
      console.error('AI configuration error:', error);
      res.status(500).json({ message: "Failed to configure AI service" });
    }
  });

  // Telegram Bot routes
  app.post("/api/telegram/configure", async (req, res) => {
    try {
      const { botToken } = req.body;
      
      telegramService.setToken(botToken);
      const connected = await telegramService.testConnection();
      
      if (connected) {
        res.json({ message: "Telegram bot configured successfully" });
      } else {
        res.status(400).json({ message: "Failed to connect to Telegram bot" });
      }
    } catch (error) {
      console.error('Telegram configuration error:', error);
      res.status(500).json({ message: "Failed to configure Telegram bot" });
    }
  });

  app.post("/api/telegram/send", async (req, res) => {
    try {
      const { contentId, channels } = req.body;
      
      const content = await storage.getContentItem(contentId);
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }

      const message = {
        title: content.title,
        summary: content.customizedContent || content.aiSummary || content.description || content.content || '',
        link: content.url
      };

      const result = await telegramService.sendToMultipleChannels(message, channels);
      
      // Update content status to posted
      await storage.updateContentItem(contentId, { 
        status: 'posted',
        telegramChannels: channels
      });

      await storage.createWorkflowLog({
        type: "post",
        status: "success",
        message: `Content posted to ${result.success.length} channels`,
        metadata: { 
          contentId,
          successChannels: result.success,
          failedChannels: result.failed
        },
      });

      res.json({ 
        message: "Content sent successfully",
        result 
      });
    } catch (error) {
      console.error('Telegram send error:', error);
      res.status(500).json({ message: "Failed to send to Telegram" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
