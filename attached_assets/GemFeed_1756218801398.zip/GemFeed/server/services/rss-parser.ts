import Parser from 'feedparser';
import { Readable } from 'stream';
// @ts-ignore
import fetch from 'node-fetch';

export interface ParsedRSSItem {
  source?: string;
  category?: string;
  title: string;
  summary: string;
  link: string;
  pubDate: Date;
  guid: string;
  categories?: string[];
}

export class RSSParser {
  async parseFeed(url: string): Promise<ParsedRSSItem[]> {
    try {
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const stream = new Readable();
      stream.push(await response.text());
      stream.push(null);

      return new Promise((resolve, reject) => {
        const feedparser = new Parser();
        const items: ParsedRSSItem[] = [];

        feedparser.on('error', reject);
        feedparser.on('readable', function() {
          let item;
          while (item = feedparser.read()) {
            items.push({
              title: item.title || 'No title',
              summary: item.summary || item.description || 'No summary',
              link: item.link || '',
              pubDate: item.pubdate || new Date(),
              guid: item.guid || item.link || Math.random().toString(),
              categories: item.categories || []
            });
          }
        });

        feedparser.on('end', () => resolve(items));
        stream.pipe(feedparser);
      });
    } catch (error) {
      console.error(`Error parsing RSS feed ${url}:`, error);
      throw error;
    }
  }

  async fetchAndStoreFeeds(feedUrls: { url: string; name: string; category: string }[]): Promise<ParsedRSSItem[]> {
    const allItems: ParsedRSSItem[] = [];

    for (const feed of feedUrls) {
      try {
        console.log(`Fetching RSS feed: ${feed.name}`);
        const items = await this.parseFeed(feed.url);
        
        // Add feed metadata to items
        const itemsWithMeta = items.map(item => ({
          ...item,
          source: feed.name,
          category: feed.category
        }));

        allItems.push(...itemsWithMeta);
        console.log(`Fetched ${items.length} items from ${feed.name}`);
      } catch (error) {
        console.error(`Failed to fetch ${feed.name}:`, error);
      }
    }

    return allItems;
  }
}