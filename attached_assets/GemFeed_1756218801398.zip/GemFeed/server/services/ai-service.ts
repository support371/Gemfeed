import OpenAI from 'openai';

export interface AIConfig {
  provider: 'openai' | 'anthropic' | 'custom';
  apiKey: string;
  model?: string;
  customPrompt?: string;
}

export interface SummaryRequest {
  title: string;
  content: string;
  category?: string;
}

export class AIService {
  private openai: OpenAI | null = null;
  private config: AIConfig;

  constructor(config: AIConfig) {
    this.config = config;
    if (config.provider === 'openai' && config.apiKey) {
      this.openai = new OpenAI({
        apiKey: config.apiKey
      });
    }
  }

  async generateSummary(request: SummaryRequest): Promise<string> {
    if (!this.openai) {
      throw new Error('AI service not initialized. Please configure API keys.');
    }

    try {
      const prompt = this.buildPrompt(request);
      
      const completion = await this.openai.chat.completions.create({
        model: this.config.model || 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are a professional content curator for Telegram channels. Create concise, engaging summaries that are informative and encourage readers to click through to the full article.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 200,
        temperature: 0.7,
      });

      const summary = completion.choices[0]?.message?.content?.trim();
      
      if (!summary) {
        throw new Error('No summary generated from AI service');
      }

      return summary;
    } catch (error) {
      console.error('Error generating AI summary:', error);
      throw error;
    }
  }

  private buildPrompt(request: SummaryRequest): string {
    const { title, content, category } = request;
    
    const customPrompt = this.config.customPrompt || 
      `Rewrite this ${category || 'news'} content for Telegram in a concise, professional, engaging style:`;

    return `${customPrompt}

Title: ${title}
Content: ${content}

Instructions:
- Keep it under 150 words
- Make it engaging and informative
- Include key insights or takeaways
- Maintain professional tone
- End with a call to action if appropriate

Result:`;
  }

  async testConnection(): Promise<boolean> {
    if (!this.openai) {
      return false;
    }

    try {
      await this.openai.chat.completions.create({
        model: this.config.model || 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: 'Test connection' }],
        max_tokens: 5
      });
      return true;
    } catch (error) {
      console.error('AI service connection test failed:', error);
      return false;
    }
  }
}