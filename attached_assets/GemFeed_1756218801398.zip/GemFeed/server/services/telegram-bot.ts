// @ts-ignore
import TelegramBot from 'node-telegram-bot-api';

export interface TelegramMessage {
  title: string;
  summary: string;
  link: string;
  channelId?: string;
}

export class TelegramService {
  private bot: TelegramBot | null = null;
  private token: string = '';

  constructor(token?: string) {
    if (token) {
      this.setToken(token);
    }
  }

  setToken(token: string) {
    this.token = token;
    this.bot = new TelegramBot(token, { polling: false });
  }

  async sendMessage(message: TelegramMessage, chatId: string): Promise<boolean> {
    if (!this.bot) {
      throw new Error('Telegram bot not initialized. Please set bot token first.');
    }

    try {
      const formattedMessage = this.formatMessage(message);
      
      await this.bot.sendMessage(chatId, formattedMessage, {
        parse_mode: 'Markdown',
        disable_web_page_preview: false
      });

      console.log(`Message sent to Telegram chat ${chatId}: ${message.title}`);
      return true;
    } catch (error) {
      console.error('Error sending Telegram message:', error);
      throw error;
    }
  }

  async sendToMultipleChannels(message: TelegramMessage, chatIds: string[]): Promise<{ success: string[], failed: string[] }> {
    const results = { success: [], failed: [] };

    for (const chatId of chatIds) {
      try {
        await this.sendMessage(message, chatId);
        (results.success as any).push(chatId);
      } catch (error) {
        console.error(`Failed to send to ${chatId}:`, error);
        (results.failed as any).push(chatId);
      }
    }

    return results;
  }

  private formatMessage(message: TelegramMessage): string {
    const { title, summary, link } = message;
    
    // Escape markdown special characters
    const escapeMarkdown = (text: string) => {
      return text.replace(/[*_`\[\]]/g, '\\$&');
    };

    return `*${escapeMarkdown(title)}*

${escapeMarkdown(summary)}

[Read more](${link})`;
  }

  async testConnection(): Promise<boolean> {
    if (!this.bot) {
      return false;
    }

    try {
      const me = await this.bot.getMe();
      console.log(`Connected to Telegram bot: ${me.username}`);
      return true;
    } catch (error) {
      console.error('Telegram connection test failed:', error);
      return false;
    }
  }
}