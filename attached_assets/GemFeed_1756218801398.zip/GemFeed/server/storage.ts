import { 
  type RssFeed, 
  type InsertRssFeed,
  type ContentItem,
  type InsertContentItem,
  type WorkflowLog,
  type InsertWorkflowLog,
  type DashboardStats,
  type FeedStatus,
  type ContentPreview
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // RSS Feeds
  getRssFeeds(): Promise<RssFeed[]>;
  getRssFeed(id: string): Promise<RssFeed | undefined>;
  createRssFeed(feed: InsertRssFeed): Promise<RssFeed>;
  updateRssFeed(id: string, updates: Partial<RssFeed>): Promise<RssFeed | undefined>;
  deleteRssFeed(id: string): Promise<boolean>;
  
  // Content Items
  getContentItems(status?: string, category?: string, limit?: number): Promise<ContentItem[]>;
  getContentItem(id: string): Promise<ContentItem | undefined>;
  createContentItem(item: InsertContentItem): Promise<ContentItem>;
  updateContentItem(id: string, updates: Partial<ContentItem>): Promise<ContentItem | undefined>;
  deleteContentItem(id: string): Promise<boolean>;
  
  // Workflow Logs
  createWorkflowLog(log: InsertWorkflowLog): Promise<WorkflowLog>;
  getWorkflowLogs(limit?: number): Promise<WorkflowLog[]>;
  
  // Dashboard & Analytics
  getDashboardStats(): Promise<DashboardStats>;
  getFeedStatus(): Promise<FeedStatus[]>;
  getContentPreview(id: string): Promise<ContentPreview | undefined>;
}

export class MemStorage implements IStorage {
  private rssFeeds: Map<string, RssFeed> = new Map();
  private contentItems: Map<string, ContentItem> = new Map();
  private workflowLogs: Map<string, WorkflowLog> = new Map();

  constructor() {
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample RSS feeds
    const sampleFeeds: RssFeed[] = [
      {
        id: "1",
        name: "Krebs on Security",
        url: "https://krebsonsecurity.com/feed/",
        category: "cybersecurity",
        enabled: true,
        updateFrequency: 3600,
        lastUpdated: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        status: "active",
        errorMessage: null,
        createdAt: new Date(),
      },
      {
        id: "2",
        name: "Reuters Finance",
        url: "https://feeds.reuters.com/reuters/businessNews",
        category: "financial",
        enabled: true,
        updateFrequency: 3600,
        lastUpdated: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
        status: "active",
        errorMessage: null,
        createdAt: new Date(),
      },
      {
        id: "3",
        name: "Dark Reading",
        url: "https://www.darkreading.com/rss.xml",
        category: "cybersecurity",
        enabled: true,
        updateFrequency: 3600,
        lastUpdated: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
        status: "error",
        errorMessage: "Connection timeout",
        createdAt: new Date(),
      },
      {
        id: "4",
        name: "Inman News",
        url: "https://www.inman.com/feed/",
        category: "real_estate",
        enabled: true,
        updateFrequency: 3600,
        lastUpdated: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        status: "active",
        errorMessage: null,
        createdAt: new Date(),
      },
    ];

    sampleFeeds.forEach(feed => this.rssFeeds.set(feed.id, feed));

    // Sample content items
    const sampleContent: ContentItem[] = [
      {
        id: "content-1",
        source: "Krebs on Security",
        title: "New Zero-Day Vulnerability Discovered in Popular CMS",
        description: "A critical zero-day vulnerability has been discovered in a widely-used content management system.",
        content: "Full article content here...",
        url: "https://krebsonsecurity.com/article/example",
        published: new Date(Date.now() - 2 * 60 * 60 * 1000),
        category: "cybersecurity",
        tags: ["vulnerability", "cms", "security"],
        status: "pending",
        telegramChannels: ["security", "cybergemsecure"],
        customizedContent: null,
        aiSummary: "Critical security vulnerability found in popular CMS affecting millions of sites. Researchers working on patches. Immediate action recommended for site administrators.",
        scheduledTime: null,
        reviewedBy: null,
        reviewedAt: null,
        createdAt: new Date(),
      },
      {
        id: "content-2",
        source: "Reuters Finance",
        title: "Bitcoin Reaches New Monthly High Amid Market Rally",
        description: "Bitcoin price surges as institutional investors show renewed interest.",
        content: "Full article content here...",
        url: "https://reuters.com/article/example",
        published: new Date(Date.now() - 4 * 60 * 60 * 1000),
        category: "financial",
        tags: ["bitcoin", "cryptocurrency", "market"],
        status: "approved",
        telegramChannels: ["client", "gemassist"],
        customizedContent: null,
        aiSummary: "Bitcoin reaches new monthly high as institutional investors return to crypto markets.",
        scheduledTime: null,
        reviewedBy: "admin",
        reviewedAt: new Date(),
        createdAt: new Date(),
      },
    ];

    sampleContent.forEach(item => this.contentItems.set(item.id, item));
  }

  // RSS Feeds
  async getRssFeeds(): Promise<RssFeed[]> {
    return Array.from(this.rssFeeds.values());
  }

  async getRssFeed(id: string): Promise<RssFeed | undefined> {
    return this.rssFeeds.get(id);
  }

  async createRssFeed(feed: InsertRssFeed): Promise<RssFeed> {
    const id = randomUUID();
    const newFeed: RssFeed = {
      ...feed,
      id,
      enabled: feed.enabled ?? true,
      updateFrequency: feed.updateFrequency ?? 3600,
      lastUpdated: null,
      status: "active",
      errorMessage: null,
      createdAt: new Date(),
    };
    this.rssFeeds.set(id, newFeed);
    return newFeed;
  }

  async updateRssFeed(id: string, updates: Partial<RssFeed>): Promise<RssFeed | undefined> {
    const feed = this.rssFeeds.get(id);
    if (!feed) return undefined;
    
    const updatedFeed = { ...feed, ...updates };
    this.rssFeeds.set(id, updatedFeed);
    return updatedFeed;
  }

  async deleteRssFeed(id: string): Promise<boolean> {
    return this.rssFeeds.delete(id);
  }

  // Content Items
  async getContentItems(status?: string, category?: string, limit?: number): Promise<ContentItem[]> {
    let items = Array.from(this.contentItems.values());
    
    if (status) {
      items = items.filter(item => item.status === status);
    }
    
    if (category) {
      items = items.filter(item => item.category === category);
    }
    
    items.sort((a, b) => new Date(b.published).getTime() - new Date(a.published).getTime());
    
    if (limit) {
      items = items.slice(0, limit);
    }
    
    return items;
  }

  async getContentItem(id: string): Promise<ContentItem | undefined> {
    return this.contentItems.get(id);
  }

  async createContentItem(item: InsertContentItem): Promise<ContentItem> {
    const newItem: ContentItem = {
      ...item,
      content: item.content ?? null,
      description: item.description ?? null,
      status: item.status ?? "pending",
      tags: item.tags ?? [],
      telegramChannels: item.telegramChannels ?? [],
      customizedContent: item.customizedContent ?? null,
      aiSummary: item.aiSummary ?? null,
      scheduledTime: item.scheduledTime ?? null,
      reviewedBy: item.reviewedBy ?? null,
      reviewedAt: null,
      createdAt: new Date(),
    };
    this.contentItems.set(item.id, newItem);
    return newItem;
  }

  async updateContentItem(id: string, updates: Partial<ContentItem>): Promise<ContentItem | undefined> {
    const item = this.contentItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...updates };
    this.contentItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteContentItem(id: string): Promise<boolean> {
    return this.contentItems.delete(id);
  }

  // Workflow Logs
  async createWorkflowLog(log: InsertWorkflowLog): Promise<WorkflowLog> {
    const id = randomUUID();
    const newLog: WorkflowLog = {
      ...log,
      id,
      message: log.message ?? null,
      metadata: log.metadata ?? null,
      createdAt: new Date(),
    };
    this.workflowLogs.set(id, newLog);
    return newLog;
  }

  async getWorkflowLogs(limit = 50): Promise<WorkflowLog[]> {
    const logs = Array.from(this.workflowLogs.values());
    logs.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    return logs.slice(0, limit);
  }

  // Dashboard & Analytics
  async getDashboardStats(): Promise<DashboardStats> {
    const feeds = Array.from(this.rssFeeds.values());
    const content = Array.from(this.contentItems.values());
    
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const feedsByCategory = feeds.reduce((acc, feed) => {
      acc[feed.category] = (acc[feed.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const approvedToday = content.filter(item => 
      item.status === "approved" && 
      item.reviewedAt && 
      new Date(item.reviewedAt) >= today
    ).length;

    const postedWeek = content.filter(item => 
      item.status === "posted" && 
      item.reviewedAt && 
      new Date(item.reviewedAt) >= weekAgo
    ).length;

    const lastUpdate = feeds
      .filter(feed => feed.lastUpdated)
      .sort((a, b) => new Date(b.lastUpdated!).getTime() - new Date(a.lastUpdated!).getTime())[0]?.lastUpdated?.toISOString() || null;

    return {
      totalFeeds: feeds.length,
      activeFeeds: feeds.filter(feed => feed.enabled && feed.status === "active").length,
      pendingContent: content.filter(item => item.status === "pending").length,
      approvedToday,
      postedWeek,
      feedsByCategory,
      lastUpdate,
    };
  }

  async getFeedStatus(): Promise<FeedStatus[]> {
    const feeds = Array.from(this.rssFeeds.values());
    const content = Array.from(this.contentItems.values());
    
    return feeds.map(feed => {
      const recentContent = content.filter(item => 
        item.source === feed.name && 
        new Date(item.published) > new Date(Date.now() - 24 * 60 * 60 * 1000)
      );

      return {
        id: feed.id,
        name: feed.name,
        category: feed.category,
        status: feed.status || "unknown",
        lastUpdate: feed.lastUpdated?.toISOString() || null,
        newItems: recentContent.length,
        errorMessage: feed.errorMessage || undefined,
      };
    });
  }

  async getContentPreview(id: string): Promise<ContentPreview | undefined> {
    const item = this.contentItems.get(id);
    if (!item) return undefined;

    const telegramFormat = `🔔 <b>${item.title}</b>

📰 ${item.aiSummary || item.description}

🏷️ #${item.category.replace('_', '')} #${item.source.replace(/\s+/g, '')}
🔗 Read more: ${item.url}

💎 Powered by GEM Enterprise`;

    return {
      id: item.id,
      title: item.title,
      description: item.description || "",
      content: item.content || "",
      url: item.url,
      source: item.source,
      category: item.category,
      published: item.published.toISOString(),
      aiSummary: item.aiSummary,
      customizedContent: item.customizedContent,
      telegramFormat,
    };
  }
}

export const storage = new MemStorage();
