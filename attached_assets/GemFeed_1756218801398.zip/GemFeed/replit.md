# RSS Aggregator and Content Curation System

## Overview

This is a full-stack RSS aggregation and content curation system built for GEM Enterprise. The system collects RSS feeds from financial and cybersecurity sources, processes the content, and provides a workflow for content review and approval before distribution to Telegram channels. The application features a modern React frontend with a clean admin interface for managing feeds, reviewing content, and configuring system settings.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **UI Library**: Radix UI components with shadcn/ui design system for accessible, customizable components
- **Styling**: Tailwind CSS with custom CSS variables for theming and dark mode support
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules for modern JavaScript features
- **API Design**: RESTful API with structured error handling and request logging
- **Development**: Hot module replacement via Vite in development mode

### Data Layer
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Structured tables for RSS feeds, content items, and workflow logs
- **Storage Interface**: Abstract storage layer with in-memory implementation for development/testing

### Key Data Models
- **RSS Feeds**: Source configuration with categories (cybersecurity, financial, real_estate, general)
- **Content Items**: Parsed feed entries with status workflow (pending → approved/rejected → posted)
- **Workflow Logs**: Audit trail for all system operations

### Authentication & Security
- Session-based authentication using express-session with PostgreSQL session store
- CORS configuration for cross-origin requests
- Input validation using Zod schemas

### Development Workflow
- **Hot Reloading**: Vite development server with automatic refresh
- **Type Safety**: Shared TypeScript interfaces between frontend and backend
- **Database Migrations**: Drizzle Kit for schema management and migrations
- **Path Aliases**: Configured shortcuts for clean imports (@/, @shared/)

## External Dependencies

### Database & ORM
- **Neon Database**: PostgreSQL hosting service via @neondatabase/serverless
- **Drizzle ORM**: Type-safe database operations with drizzle-orm and drizzle-zod for validation

### UI & Styling
- **Radix UI**: Comprehensive collection of accessible React components
- **Tailwind CSS**: Utility-first CSS framework with PostCSS processing
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Fast build tool and development server
- **ESBuild**: JavaScript bundler for production builds
- **TSX**: TypeScript execution for development server

### Utilities
- **Date-fns**: Date manipulation and formatting
- **Class Variance Authority**: Utility for managing component variants
- **CLSX**: Conditional class name utility

### Planned Integrations
- **RSS Feed Parsing**: Feedparser for processing RSS/Atom feeds
- **Content Extraction**: Trafilatura for full-text content extraction
- **AI Processing**: OpenAI integration for content summarization
- **Telegram Bot**: Telegram API for automated content distribution
- **Webhook System**: Real-time notifications for content workflow events